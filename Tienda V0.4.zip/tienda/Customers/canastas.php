<?php
 include("config.php");


 $stmt_edit->execute(array(':user_id'=>$user_id));
 $edit_row = $stmt_edit->fetch(PDO::FETCH_ASSOC);
 extract($edit_row);


 $query="SELECT *  FROM orderdetails where user_id = $user_id"; 
 $resultado=mysqli_query($dbcon,$query);


 while ($query = $resultado->fetch_assoc()){
    $fila = $resultado->fetch_assoc();



    $id_ing=$fila['item_id']; 

    $query2="SELECT *  FROM items"; 
    $resultado2=mysqli_query($dbcon,$query2);

    while ($query2 = $resultado2->fetch_assoc()){
        $fila2 = $resultado->fetch_assoc();

    $nombre 
    $precio
    $cantidad
    $total
    $status 
    $fecha 
    $medida 

 if( $id_ing >= 0 ){
    $query="UPDATE orderdetails SET  candisp=candisp-$order_quantity,cantres=cantres+$order_quantity WHERE `item_id`=$id_ing and user_id = $user_id";
     mysqli_query($dbcon,$query);

      $save_order_details="insert into orderdetails (user_id,order_name,order_price,order_quantity,order_total,order_status,item_id) VALUE ('$user_id','$order_name','$order_price','$order_quantity','$order_total','$order_status',$item_id)";
        mysqli_query($dbcon,$save_order_details);

   
  
 }

 }
}

?>