<?php
//$dbcon=new mysqli("localhost:3306","servido2","","servido2_dbrecette"); //servidor, usuario de base de datos, contraseña del usuario, nombre de base de datos

$DB_HOST = 'localhost:3306';
$DB_USER = 'servido2';
$DB_PASS = '7joi2k3PJ8';
$DB_NAME = 'servido2_dbrecette';
	
	try{
		$DB_con = new PDO("mysql:host={$DB_HOST};dbname={$DB_NAME}",$DB_USER,$DB_PASS);
		$DB_con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	catch(PDOException $e){
		echo $e->getMessage();
	}
	
