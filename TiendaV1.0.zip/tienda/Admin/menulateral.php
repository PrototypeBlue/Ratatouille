<li class="active"><a href="index.php"> &nbsp; &nbsp; &nbsp; Inicio</a></li>
					<li><a data-toggle="modal" data-target="#uploadModal"> &nbsp; &nbsp; &nbsp; Cargar ingredientes</a></li>
					<li><a href="items.php"> &nbsp; &nbsp; &nbsp; Mantenimiento de ingre.</a></li>
					<li><a href="AgregarReceta.php"> &nbsp; &nbsp; &nbsp; Cargar recetas</a></li>
					<li><a href="Recetas.php"> &nbsp; &nbsp; &nbsp; Mantenimiento de recetas</a></li>
					<li><a href="customers.php"> &nbsp; &nbsp; &nbsp; Mantenimiento de usuarios</a></li>
			<!--		<li><a href="orderdetails.php"> &nbsp; &nbsp; &nbsp; Detalles Ordenes</a></li> -->
                   
              <!--     <li><a href="cargamasivapicking.php"> &nbsp; &nbsp; &nbsp; Picking de Ordenes</a></li> -->
                  <!-- <li><a href="cargamasivaconfirmacion.php"> &nbsp; &nbsp; &nbsp; Confirmacion de Ordenes</a></li> -->
			    <!--	<li><a href="cargamasivaitems.php"> &nbsp; &nbsp; &nbsp; Recepcion de Mercancia</a></li> -->
					<li><a href="editcia.php"> &nbsp; &nbsp; &nbsp; Gestion de Compañia</a></li>
					<li><a href="editimg.php"> &nbsp; &nbsp; &nbsp; Imagenes de Carrucel</a></li>
					
					
					<li><a href="logout.php"> &nbsp; &nbsp; &nbsp; Cerrar sesión</a></li>