<?php
include "db.php";
delall(1);
?>