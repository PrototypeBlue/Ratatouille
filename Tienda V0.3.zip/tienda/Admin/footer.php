  
 <div class="alert alert-default" style="background-color:#033c73;">
       <p style="color:white;text-align:center;">
        &copy 2020 Ratatouille | Todos los derechos reservados | Harry Palma
	 </p>

   </div>